<!DOCTYPE html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js"> <!--<![endif]-->

<!-- templatemo 417 grill -->
<!-- 
Grill Template 
http://www.templatemo.com/preview/templatemo_417_grill 
--><?php
  //Если форма отправлена
  if(isset($_POST['submit'])) {
 //Проверка Поля ИМЯ
  if(trim($_POST['contactname']) == '') {
  $hasError = true;
  } else {
  $name = trim($_POST['contactname']);
  }
 //Проверка поля ТЕМА
  if(trim($_POST['subject']) == '') {
  $hasError = true;
  } else {
  $subject = trim($_POST['subject']);
  }
 //Проверка правильности ввода EMAIL
  if(trim($_POST['email']) == '')  {
  $hasError = true;
  } else if (!eregi("^[A-Z0-9._%-]+@[A-Z0-9._%-]+\.[A-Z]{2,4}$", trim($_POST['email']))) {
  $hasError = true;
  } else {
  $email = trim($_POST['email']);
  }
 //Проверка наличия ТЕКСТА сообщения
  if(trim($_POST['message']) == '') {
  $hasError = true;
  } else {
  if(function_exists('stripslashes')) {
  $comments = stripslashes(trim($_POST['message']));
  } else {
  $comments = trim($_POST['message']);
  }
  }
 //Если ошибок нет, отправить email
  if(!isset($hasError)) {
  $emailTo = 'astas2286@gmail.com'; //Сюда введите Ваш email
  $body = "Name: $name \n\nEmail: $email \n\nSubject: $subject \n\nComments:\n $comments";
  $headers = 'From: My Site <'.$emailTo.'>' . "\r\n" . 'Reply-To: ' . $email;
 mail($emailTo, $subject, $body, $headers);
  $emailSent = true;
  }
  }
  ?>
    <head>
        <meta charset="utf-8">
        <title>Контакти - Honey Restaurant & Club</title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width">
        
        <link href='http://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,800italic,400,300,600,700,800' rel='stylesheet' type='text/css'>

        <link rel="stylesheet" href="css/bootstrap.css">
        <link rel="stylesheet" href="css/font-awesome.css">
        <link rel="stylesheet" href="css/templatemo_style.css">
        <link rel="stylesheet" href="css/templatemo_misc.css">
        <link rel="stylesheet" href="css/flexslider.css">
        <link rel="stylesheet" href="css/testimonails-slider.css">
<script src="jquery.min.js" type="text/javascript"></script>
      <script src="jquery.validate.pack.js" type="text/javascript"></script>
<script type="text/javascript">
      $(document).ready(function(){
      $("#contactform").validate();
      });
  </script>  
        <script src="js/vendor/modernizr-2.6.1-respond-1.1.0.min.js"></script>
    </head>
    <body>
        <!--[if lt IE 7]>
            <p class="chromeframe">You are using an outdated browser. <a href="">Upgrade your browser today</a> or <a href="">install Google Chrome Frame</a> to better experience this site.</p>
        <![endif]-->

                        <header>
				<div id="main-header">
                    <div class="container">
                        <div class="row">
                            <div class="col-md-3">
                                <div class="logo">
                                    <a href="index.html"><img src="images/logo.png" title="Grill Template" alt="Grill Website Template by templatemo.com" ></a>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="main-menu">
                                    <ul>
                                        <li><a href="index.html">Головна</a></li>
                                        <li><a href="about-us.html">Про нас</a></li>
                                        <li><a href="gallery.html">Галерея</a></li>
                                        <li><a href="contact-us.html">Контакти</a></li>
                                    </ul>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="search-box">  
                                    <form name="search_form" method="get" class="search_form">
                                        <input id="search" type="text" />
                                        <input type="submit" id="search-button" />
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </header>


<div id="heading">
                <div class="container">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="heading-content">
                                <h2>Зв'яжіться з нами</h2>
                            </div>
                        </div>
                    </div>
                </div>
            </div>


            <div id="product-post">
                <div class="container">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="heading-section">
                                <h2>Надішліть нам повідомлення</h2>
                                <img src="images/under-heading.png" alt="" >
                            </div>
                        </div>
                    </div>
                    <div id="contact-us">
                        <div class="container">
                            <div class="row">
                                <div class="product-item col-md-12">
                                    <div class="row">
                                        <div class="col-md-8">  
                                            <div class="message-form">
                                                <form action="<?php echo $_SERVER['PHP_SELF']; ?>" id="contactform" method="post" class="send-message">
                                                    <div class="row">
                                                    <div class="name col-md-4">
                                                        <input type="text" name="name" id="name" placeholder="Ім'я" />
                                                    </div>
                                                    <div class="email col-md-4">
                                                        <input type="text" name="email" id="email" placeholder="Email" />
                                                    </div>
                                                    <div class="subject col-md-4">
                                                        <input type="text" name="subject" id="subject" placeholder="Тема" />
                                                    </div>
                                                    </div>
                                                    <div class="row">        
                                                        <div class="text col-md-12">
                                                            <textarea name="text" placeholder="Повідомлення"></textarea>
                                                        </div>   
                                                    </div>                              
                                                    <div class="send">
                                                        <button type="submit">Готово</button>
                                                    </div>
                                                </form>
                                            </div>
											
											<form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>" id="contactform">
<div>

<label for="name"><strong>Name:</strong></label>
<input type="text" size="50" name="contactname" id="contactname" value="" class="required" />
</div>
 <div>
  <label for="email"><strong>Email:</strong></label>
  <input type="text" size="50" name="email" id="email" value="" class="required email" />
  </div>
 <div>
  <label for="subject"><strong>Subject:</strong></label>
  <input type="text" size="50" name="subject" id="subject" value="" class="required" />
  </div>
 <div>
  <label for="message"><strong>Message:</strong></label>
  <textarea rows="5" cols="50" name="message" id="message" class="required"></textarea>
  </div>
  <input type="submit" value="Send Message" name="submit" />
  </form>
											
                                        </div>
                                        <div class="col-md-4">
                                            <div class="info">
                                                <p>Відвідайте нас за вказанною нижче адресою. Також Ви можете зв'язатися з нами з питань замовлення, або надіслати нам Ваші пропозиції.</p>
                                                <ul>
                                                    <li><i class="fa fa-phone"></i>+38 066 696 00 06</li>
													<li><i class="fa fa-globe"></i>м. Ужгород, вул. Капушанська, 59</li>
													<li><i class="fa fa-envelope"></i><a href="honey.uzhgorod@gmail.com">honey.uzhgorod@gmail.com</a></li>
                                                </ul>
                                            </div>
                                        </div>     
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-12">
                            <div class="heading-section">
                                <h2>Як нас знайти</h2>
                                <img src="images/under-heading.png" alt="" >
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-12">
                            <div id="googleMap" style="height:420px;"></div>
                        </div>
                    </div>     
                </div>
            </div>

			<footer>
                <div class="container">

                    <div class="main-footer">
                        <div class="row">
                            <div class="col-md-3">
                                <div class="about">
                                    <h4 class="footer-title">Про Honey</h4>
                                    <p><a rel="nofollow" href="">Honey Restaurant & Club</a> Ресторан і тераса, розташовані в м. Ужгород. Затишна атмосфера, привітний персонал та неперевершені страви.  
                                    <br><br>Приймаються попередні <a rel="nofollow" href="">замовлення</a> на корпоративи, дні народження, весілля, 	сімейні свята та вечірки.</p>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="shop-list">
                                    <h4 class="footer-title">Пропозиції</h4>
                                    <ul>
                                        <li><a href="#"><i class="fa fa-angle-right"></i>Вишукані коктейлі</a></li>
                                        <li><a href="#"><i class="fa fa-angle-right"></i>Бездоганний смак</a></li>
                                        <li><a href="#"><i class="fa fa-angle-right"></i>Прості та смачні страви</a></li>
                                        <li><a href="#"><i class="fa fa-angle-right"></i>Порятунок від спеки</a></li>
                                        <li><a href="#"><i class="fa fa-angle-right"></i>Вишукані вина</a></li>
                                        <li><a href="#"><i class="fa fa-angle-right"></i>Запрошуємо на кальян</a></li>
                                    </ul>
                                </div>
                            </div>
                            
                            <div class="col-md-3">
                                <div class="more-info">
                                    <h4 class="footer-title">Зв'яжіться з нами</h4>
                                    <p>Відвідайте нас за вказанною нижче адресою. Також Ви можете зв'язатися з нами з питань замовлення, або надіслати нам Ваші пропозиції.</p>
                                    <ul>
                                        <li><i class="fa fa-phone"></i>+38 066 696 00 06</li>
                                        <li><i class="fa fa-globe"></i>м. Ужгород, вул. Капушанська, 59</li>
                                        <li><i class="fa fa-envelope"></i><a href="honey.uzhgorod@gmail.com">honey.uzhgorod@gmail.com</a></li>
                                    </ul>
                                </div>
								</div>
								<div class="col-md-3">
								<div class="social-bottom">
                                    <span>Приєднуйтесь до нас у Facebook <a href="https://www.facebook.com/Honey-Restaurant-Club-1448702428716211/?fref=ts" target="_blank" class="fa fa-facebook"></a></span>
                                </div>
								</div>
                            </div>
                    </div>
				</div>
            </footer>

        <script src="js/vendor/jquery-1.11.0.min.js"></script>
        <script src="js/vendor/jquery.gmap3.min.js"></script>
        <script src="js/plugins.js"></script>
        <script src="js/main.js"></script>

        <script src="http://maps.googleapis.com/maps/api/js?key=AIzaSyDY0kkJiTPVd2U7aTOAwhc9ySH6oHxOIYM&amp;sensor=false">
        </script>
                
        <script>
		
		var map;
		
        function initialize()
        {
			var map_options = {
			  center: new google.maps.LatLng(48.617098, 22.285823),
			  zoom: 15,
			  mapTypeId:google.maps.MapTypeId.ROADMAP
			  };
			var map = new google.maps.Map(document.getElementById("googleMap"), map_options);
        }

        google.maps.event.addDomListener(window, 'load', initialize);
		google.maps.event.addDomListener(window, "resize", function() 
		{
		 	var center = map.getCenter();
		 	google.maps.event.trigger(map, "resize");
		 	map.setCenter(center); 
		});

        </script>

    </body>
</html>